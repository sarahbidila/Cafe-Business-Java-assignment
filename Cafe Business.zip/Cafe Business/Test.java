import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Test {
    public static void main (String[] args){
        //instance creation
        CafeUtil allApp = new CafeUtil();
        System.out.println ("---------------------------------------");
        System.out.println ("***The streak Goal***");
        System.out.printf("purchases needed by week 10 : %s \n",allApp.getStreakGoal());
    

    //declare the items
    double[] lineItems = {3.5,4.2,7.0,7.1} ;
    System.out.println("***Order Total***");
    System.out.printf("Order Total is : %.2f\n",allApp.getOrderTotal(lineItems));
    System.out.println("***Menu***");
    //create a list of coffee : 
    List<String> myMenu = Arrays.asList(
        "drip coffee","capuccino","latte","mocha"
    );
    ArrayList<String> menu = new ArrayList<String>();
    //adding the list in an array
    menu.addAll(myMenu);
    //preview if the list is added : 
    //System.out.println(menu);
    allApp.displayMenu(menu);

    System.out.println("***Customer side***");
    
    ArrayList<String> customer = new ArrayList<String>();
    
    for (int i=0;i<4;i++){
        allApp.addCustomer(customer);
     

    }
    System.out.println ("---------------------------------------");
    }
}