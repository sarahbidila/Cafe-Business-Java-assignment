import java.util.ArrayList;
import java.util.Arrays;

public class CafeUtil {
    //streak goal by weeks
    public int getStreakGoal(){
        int sum = 0;
        int week = 1;
        for (week=1;week<=10;week++){
            sum = week + sum;
           
        }
        return sum;
    }

    //getOrderTotal
    public double getOrderTotal(double[] lineItems){
        double sumPrice = 0;
        for (double price: lineItems){
            sumPrice = price + sumPrice;
        }
        return sumPrice;
    }

    //MenuList
    public void displayMenu(ArrayList<String> menuItems){
        int i = 0;
        //The size of an ArrayList can be obtained by using the java. util. ArrayList. size() method
        for (i=0;i< menuItems.size();i++){
          System.out.printf("%s - %s \n",i,menuItems.get(i));
        }
    }
    //add customer 
    public void addCustomer(ArrayList<String> customersList){
        System.out.println("please enter customer's name : ...");
        String userName = System.console().readLine();
        System.out.printf("Welcome %s",userName);
        System.out.printf("there are %s before you, please wait your turn \n",customersList.size());
        customersList.add(userName);
        System.out.println(customersList);
    }
    
}